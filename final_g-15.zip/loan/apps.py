from django.apps import AppConfig


class loanConfig(AppConfig):
    name = 'loan'
